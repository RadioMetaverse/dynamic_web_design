<?php

$myData = $_POST['data'];  //This recieves the data passed from JavaScript

print "<p>Hello ".$myData."! How are you?</p>";

?>