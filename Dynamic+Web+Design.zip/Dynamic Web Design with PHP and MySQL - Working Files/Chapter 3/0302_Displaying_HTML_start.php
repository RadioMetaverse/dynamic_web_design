<?php
print "<html>\n";
print "<head><title>0302 Displaying HTML</title>\n";
print "<style>body {font-family: Arial, Helvetica, sans-serif; font-size: 16px;}</style>\n";
print "\n ";
print "<body>\n";
print "	<h1>0302 Displaying HTML</h1>\n";
print "	<p>What are script tags and why do we need them to run PHP?</p>\n";
print "\n ";

$today = date('Y-m-d h:g:s');

print "<p><b>Today is $today </b></p>\n";
print " ";
print "</body>\n";
print " ";
print "</html>\n";
?>